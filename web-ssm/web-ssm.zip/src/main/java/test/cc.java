/*
 * Copyright (c) 2014-2017 墨博云舟 All Rights Reserved
 */

package test;

/**
 * cc :
 *
 * @author chenming
 * @version 1.00
 * @since 2017-10-31 10:13
 */
public class cc {
    public static void main(String args[]) {
        Student student = new Student();
        System.out.println(student.getAge());
    }
}
