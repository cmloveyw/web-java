package com.heitian.ssm.base.model;

import java.io.Serializable;

/**
 * Des: 基础：mapper更新(add,update,insert等数据变化操作)模型
 * Created by UlverYang on 2016-12-26 14:53.
 */
public class BaseUpdateModel implements Serializable {


}
