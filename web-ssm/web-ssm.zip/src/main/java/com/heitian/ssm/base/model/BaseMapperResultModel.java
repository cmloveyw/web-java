package com.heitian.ssm.base.model;

import java.io.Serializable;

/**
 * Des: mapper xml 自定义返回结果model
 * Created by UlverYang on 2016-12-26 14:35.
 */
public class BaseMapperResultModel implements Serializable {

}
