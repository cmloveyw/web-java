/*
 *  Copyright (c) 2014-2017. 墨博云舟 All Rights Reserved. 
 */

package com.heitian.ssm.base.entity.entity;

import java.io.Serializable;

/**
 * Entity : 根实体
 *
 * @author UlverYang
 * @version 1.00
 * @since 2017-03-08 17:46
 */
public interface Entity extends Serializable {

}
