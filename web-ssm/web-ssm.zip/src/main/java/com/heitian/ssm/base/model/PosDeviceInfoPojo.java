/**
 * Copyright (c) 2014-2017 墨博云舟 All Rights Reserved. 
 */
package com.heitian.ssm.base.model;

/**
 * Des:
 * Created by UlverYang[yang.jian@mobcb.com] on 2017-02-23 17:20.
 */
public class PosDeviceInfoPojo {
    private String id;
    private String num; // 机器号(台号)

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}